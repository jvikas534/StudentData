import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Date;


import com.toedter.calendar.JDateChooser;


public class StudentData extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private JDateChooser dateChooser;
	private JDateChooser dateChooser_1;
	private JTextField textField_2;
	static final String QUERY = "SELECT id, first, last, age FROM Registration";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentData frame = new StudentData();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentData() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 925, 447);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			        try
			        {
			        	Class.forName("com.mysql.jdbc.Driver");
			        	Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/1lAIHXc8Va","1lAIHXc8Va","TEMA3CTgGO");
			        	
			        	PreparedStatement ps = conn.prepareStatement("insert into studentdata(STUDENT_NO,STUDENT_NAME,STUDENT_DOB,STUDENT_DOJ) Values(?,?,?,?)");
						ps.setString(1, textField.getText());
						ps.setString(2, textField_1.getText());
						Date date1 = new Date(dateChooser.getDate().getTime());
						ps.setDate(3, date1);
			    		Date date2 = new Date(dateChooser_1.getDate().getTime());
						ps.setDate(4, date2);
						
						int rs = ps.executeUpdate();
						
						if(rs>0) {
							
							JOptionPane.showMessageDialog(null, "Recorded Successfully....  ");
						}
			        }
			        catch (ClassNotFoundException e)
			        {
			            e.printStackTrace();
			            JOptionPane.showMessageDialog(null, "Connectin Not  Successfully....  ");
			            
			        }
			        catch (SQLException e)
			        {
			        	e.printStackTrace();
			            JOptionPane.showMessageDialog(null, "Query Not Successfully....  ");
			            
			        }catch (Exception e)
			        {
			        	e.printStackTrace();
			            JOptionPane.showMessageDialog(null, "Recorded Not Successfully....  ");
			            
			        }
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(39, 332, 70, 35);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener()  {
			public void actionPerformed(ActionEvent arg0) {
				
				try
		        {
		        	
					Class.forName("com.mysql.jdbc.Driver");
		        	Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/1lAIHXc8Va","1lAIHXc8Va","TEMA3CTgGO");
		        	
					PreparedStatement s = conn.prepareStatement("UPDATE studentdata set STUDENT_NAME = ?, STUDENT_DOB = ?,STUDENT_DOJ = ? where STUDENT_NO = ?");
					s.setString(1, textField_1.getText());
					Date date1 = new Date(dateChooser.getDate().getTime());
					s.setDate(2, date1);
					Date date2 = new Date(dateChooser_1.getDate().getTime());
					s.setDate(3, date2);
	                s.setString(4, textField.getText());
					int x = s.executeUpdate();
					if(x>0) {
						
						JOptionPane.showMessageDialog(null, "Record Updated Successfully....  ");
					}
		        }	
				
		        catch (ClassNotFoundException e)
		        {
		            e.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Connectin Not  Successfully....  ");
		            
		        }
		        catch (Exception e)
		        {
		        	e.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Record Not Updated Successfully....  ");
		            
		        }
		        
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setBounds(153, 332, 76, 35);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try
			    {
			      
			      Class.forName("com.mysql.jdbc.Driver");
			      Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/1lAIHXc8Va","1lAIHXc8Va","TEMA3CTgGO");
			       
			      String query = "delete from studentdata where STUDENT_NO = ?";
			      PreparedStatement ps = conn.prepareStatement(query);
			      ps.setString(1, textField.getText());

			      int b = ps.executeUpdate();
			      
			      if(b>0) {
				      
			    	  JOptionPane.showMessageDialog(null,"Recoed Deleted Successfully.....");
			      }
			      else  {
			    	  
			    	  JOptionPane.showMessageDialog(null,"Enter Student NO ");  
			      }
			      
			      conn.close();
			    }
			    catch (Exception e)
			    {
			      
			    	JOptionPane.showMessageDialog(null, "Connection Not Successfully\n"+e.getMessage());
			     
			    }
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_2.setBounds(279, 332, 70, 35);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("AllRecord");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/1lAIHXc8Va","1lAIHXc8Va","TEMA3CTgGO");
					PreparedStatement ps = conn.prepareStatement("select * from studentdata");
					ResultSet rs = ps.executeQuery();
					
					table.getColumnModel().getColumn(0).setHeaderValue("STUDENT_NO");
					table.getColumnModel().getColumn(1).setHeaderValue("STUDENT_NAME");
					table.getColumnModel().getColumn(0).setHeaderValue("STUDENT_DOB");
					table.getColumnModel().getColumn(1).setHeaderValue("STUDENT_DOJ");
					
					while(table.getRowCount() > 0) {
						((DefaultTableModel) table.getModel()).removeRow(0);
					}
					
					int columns = rs.getMetaData().getColumnCount();
					
		            while (rs.next()) {  
		            	
		                Object[] row = new Object[columns];
		                for (int i = 1; i <= columns; i++)
		                {  
		                    row[i-1] = rs.getObject(i); // 1
		                }
		                ((DefaultTableModel) table.getModel()).insertRow(rs.getRow()-1, row);
		            }
		            
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, "Connection Not Successfully\n"+e.getMessage());
				}
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_3.setBounds(616, 31, 111, 35);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try
		        {
		            Class.forName("com.mysql.jdbc.Driver");
		            Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/1lAIHXc8Va","1lAIHXc8Va","TEMA3CTgGO");

		            String StrQr="";
		            if (textField_2.getText().trim().length()>0 )
		            {
		                StrQr =StrQr + " and STUDENT_NO = " + textField_2.getText().trim() + " ";
		            }
		            
		            
		            if (StrQr.length()==0)
		            {
		               JOptionPane.showMessageDialog(null,"Enter Student No/ID");
		                return;
		            }
		            
		            PreparedStatement ps=conn.prepareStatement("select STUDENT_NO, STUDENT_NAME, STUDENT_DOB, STUDENT_DOJ from studentdata where 1=1 " + StrQr + " order by STUDENT_NO");
		            ResultSet rs = ps.executeQuery();
		            
		            table.getColumnModel().getColumn(0).setHeaderValue("STUDENT_NO");
		            table.getColumnModel().getColumn(1).setHeaderValue("STUDENT_NAME");
		            table.getColumnModel().getColumn(2).setHeaderValue("STUDENT_DOB");
		            table.getColumnModel().getColumn(3).setHeaderValue("STUDENT_DOJ");
		            table.getTableHeader().resizeAndRepaint();

		            while (table.getRowCount() > 0) {
		                ((DefaultTableModel) table.getModel()).removeRow(0);
		            }  
		            
		            int columns = rs.getMetaData().getColumnCount();
		            while (rs.next()) {  
		                Object[] row = new Object[columns];
		                for (int i = 1; i <= columns; i++)
		                {  
		                    row[i - 1] = rs.getObject(i); // 1
		                }
		                ((DefaultTableModel) table.getModel()).insertRow(rs.getRow() - 1,row);
		            }

		        }
		        catch (Exception e) {
		        	JOptionPane.showMessageDialog(null, "Connection Not Successfully\n"+e.getMessage());
		            
		        }
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_4.setBounds(316, 36, 97, 35);
		contentPane.add(btnNewButton_4);
		
		textField = new JTextField();
		textField.setBounds(176, 100, 192, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(176, 159, 192, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(176, 211, 192, 27);
		contentPane.add(dateChooser);
		
		dateChooser_1 = new JDateChooser();
		dateChooser_1.setBounds(176, 269, 192, 27);
		contentPane.add(dateChooser_1);
		
		JLabel lblNewLabel = new JLabel("Student No  :");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(39, 99, 90, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Student Name  :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(39, 158, 96, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Student DOB  :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(39, 211, 90, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Student DOJ  :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(39, 269, 96, 27);
		contentPane.add(lblNewLabel_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(436, 77, 463, 290);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"        Student_No", "     Student_Name", "      Student_DOB", "      Student_DOJ"
			}
		));
		table.setFont(new Font("Tahoma", Font.PLAIN, 12));
		table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_4 = new JLabel("Student ID  :");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(39, 41, 90, 25);
		contentPane.add(lblNewLabel_4);
		
		textField_2 = new JTextField();
		textField_2.setBounds(176, 39, 118, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
	}	
}
